# EDA #level1: Orbital simulation

## Integrantes del grupo y contribución al trabajo de cada integrante

* [Nombre]: [contribución]

[completar]

## Verificación del timestep

[completar]

## Verificación del tipo de datos float

[completar]

## Complejidad computacional con asteroides

[completar]

## Mejora de la complejidad computacional

[completar]

## Bonus points

[completar]

/**
 * @brief Lequel? language identification based on trigrams
 * @author Marc S. Ressl
 *
 * @copyright Copyright (c) 2022-2023
 *
 * @cite https://towardsdatascience.com/understanding-cosine-similarity-and-its-application-fd42f585296a
 */

#include <cmath>
#include <codecvt>
#include <locale>
#include <iostream>

#include "Lequel.h"

using namespace std;

/**
 * @brief Builds a trigram profile from a given text.
 *
 * @param text Vector of lines (Text)
 * @return TrigramProfile The trigram profile
 */
TrigramProfile buildTrigramProfile(const Text &text)
{
    wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;

    TrigramProfile Profile; // Inicializo un "TrigramProfile" a devolver

    int stringpointer = 0;

    for (auto line : text)
    {
        if ((line.length() > 0) &&
            (line[line.length() - 1] == '\r'))
            line = line.substr(0, line.length() - 1); // Da una linea de texto a cortar.

        wstring unicodeString = converter.from_bytes(line);
        for (int stringpointer = 0; (stringpointer < unicodeString.length() - 2) && (unicodeString.length() > 2); stringpointer++)
        {
            wstring unicodeTrigram = unicodeString.substr(stringpointer, 3); // Corta las lineas para darnos un trigrama.

            string trigram = converter.to_bytes(unicodeTrigram); // Pasa el trigrama al formato a almacenar en el TrigramProfile.

            // Identifico si el trigrama ya pertenece al TrigramProfile y sino lo a�ado.

            auto iterator = Profile.find(trigram); // Si encuentra el elemento, da un puntero a este, sino da el iterador end().

            if (iterator == Profile.end())
            {
                Profile.insert({ trigram, 1 }); // A�ade el trigrama en un nuevo lugar del mapa.
            }
            else
                iterator->second = (iterator->second) + 1; //  Aumenta su frecuencia en 1
        }
    }

    // Tip: converts UTF-8 string to wstring
    //wstring unicodeString = converter.from_bytes(textLine);

    // Tip: convert wstring to UTF-8 string
    // string trigram = converter.to_bytes(unicodeTrigram);

    return Profile; // Fill-in result here
}


/**
 * @brief Normalizes a trigram profile.
 *
 * @param trigramProfile The trigram profile.
 */
void normalizeTrigramProfile(TrigramProfile &trigramProfile)
{
    float SumOfSquares = 0;
    float Norm = 0;

    for (const auto& element : trigramProfile)
    {
        SumOfSquares += element.second * element.second;
    }

    Norm = sqrt(SumOfSquares);

    for (auto& element : trigramProfile) 
    {
        element.second = element.second / Norm;
    }

    return;
}

/**
 * @brief Calculates the cosine similarity between two trigram profiles
 *
 * @param textProfile The text trigram profile
 * @param languageProfile The language trigram profile
 * @return float The cosine similarity score
 */
float getCosineSimilarity(TrigramProfile &textProfile, TrigramProfile &languageProfile)
{
    float CosineSimilarity = 0.0; //Esta inicializado en 0, para devolverlo por defecto en caso de no encontrar el trigrama en 
                                 //languageProfiles
                       
    for (auto const& pair : textProfile) {
        string trigram = pair.first;    //guardo el trigrama
        float textFrequency = pair.second;  //guardo su frecuencia

        // Verificar si el trigrama est� presente en el perfil de lenguajes dados, si esta, devuelve un iterador distinto de end()
        if (languageProfile.find(trigram) != languageProfile.end()) {
            float languageFrequency = languageProfile[trigram];

            // Calcular el producto de las frecuencias de los trigramas comunes y sumarlos
            CosineSimilarity += textFrequency * languageFrequency;
        }
    }

    return CosineSimilarity;

}

/**
 * @brief Identifies the language of a text.
 *
 * @param text A Text (vector of lines)
 * @param languages A list of Language objects
 * @return string The language code of the most likely language
 */
string identifyLanguage(const Text &text, LanguageProfiles &languages)
{
    // Your code goes here...
    float highestCosineSimilarity = 0;
    TrigramProfile textTrigramProfile = buildTrigramProfile(text);
    std::string mostSimilarLanguage;

    normalizeTrigramProfile(textTrigramProfile);

    for (auto& element : languages) //recorre los lidiomas
    {
        // Comparo la similitud del texto con los idiomas, uno por uno. El de mayor similitud se guarda en HighestCosineSimilarity
        // y asi sucesivamente, hasta recorrer todos los lenguajes
        if (getCosineSimilarity(textTrigramProfile, element.trigramProfile) > highestCosineSimilarity) { 
            highestCosineSimilarity = getCosineSimilarity(textTrigramProfile, element.trigramProfile); 
            mostSimilarLanguage = element.languageCode;  
        }

    }

    return mostSimilarLanguage; // Fill-in result here
}

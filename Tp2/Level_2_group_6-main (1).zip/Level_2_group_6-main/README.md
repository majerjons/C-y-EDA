# EDA #level2: Lequel?

## Integrantes del grupo y contribución al trabajo de cada integrante

* [Nombre]: 
* Solar Grillo, Lucas. Bonus 1, 2, getCosineSimilarity y identifyLanguage.
* Gastaldi, Rocco. normalizeTrigramProfile y identifyLanguage.
* Rojana, Ignacio. buildTrigramProfile y identifyLanguage.
		

[completar]

## Respuestas del enunciado

1. ¿En qué idioma está el siguiente texto?

історія земель сучасної України, українського народу та інших національностей, що проживають на території України, від доісторичних часів до сьогодення.
Ucraniano.


2. ¿En qué idioma está el siguiente texto?

아리랑, 아리랑, 아라리요... 아리랑 고개로 넘어간다. 나를 버리고 가시는 님은 십리도 못가서 발병난다. 청천하늘엔 잔별도 많고, 우리네 가슴엔 희망도 많다. 저기 저 산이 백두산이라지, 동지 섣달에도 꽃만 핀다.
Coreano.


3. ¿En qué idioma está el siguiente texto?

၁၉၄၀ ခုနှစ်တွင် ဗိုလ်ချုပ်အောင်ဆန်းဦးဆောင်သည့် ရဲဘော်သုံးကျိပ်အဖွဲ့ဝင်တို့သည် ဗမာ့လွတ်မြောက်ရေးတပ်မတော် (ဘီအိုင်အေ) ကို တည်ထောင်ခဲ့ကြသည်။[၂၀][၂၀] ရဲဘော်သုံးကျိပ်သည် ဂျပန်နိုင်ငံတွင် စစ်သင်တန်းများတက်ရောက်ခဲ့ကြသည်။[၂၀]
Birmano.


4. ¿En qué idioma está el siguiente texto?

Negema wangu binti, mchachefu wa sanati upulike wasiati asa ukanzingatia. Maradhi yamenshika hatta yametimu mwaka sikupata kutamka neno lema kukwambia. Ndoo mbee ujilisi na wino na qaratasi moyoni nina hadithi nimependa kukwambia.
Suajili.


5. ¿En qué idioma está el siguiente texto?

Այժմ նա յուր կինտոյի արհեստով ժառանգած Ճանճուր մականունը կցելով յուր հոր՝ Օհանեսի անվան հետ, կոչվում է «Թիֆլիսի պատվավոր քաղաքացի Ճանճուր Իվանիչ»։ Այդ անունով ևս մենք պարտավորվում ենք նրան ծանոթացնել մեր ընթերցողներին։
Armenio.


6. ¿En qué idioma está el siguiente texto?

Belirli bir bölgedeki mevcut hava durumu hava raporu, gelecekte beklenen durumlar ise hava tahmini şeklinde, ilgili meteoroloji otoriteleri tarafından yayımlanır.
Turco.


7. ¿En qué idioma está el siguiente texto?

ᎤᎵᏍᏔᏴᏗ ᎦᎵᏙᏗ ᏭᎷᏤᎢ, ᎤᏗᏔᎮ ᎦᏁᎲ, ᎤᏲᏏᏍᎩ ᎤᏗᏔᎮ ᎤᏅᏗ ᏃᎴ ᎤᎩᏍᏙᎡ ᏑᎾᎴ ᎠᎩᏍᏗ ᎤᏂᏑᎸᏓ. ᎣᏍᏓ ᏄᎵᏍᏔᏁᎮ ᎤᏩᏌ ᎤᏪᏅᏒ ᎡᏙᎲ. ᎦᏅᏆᎶᏍᏗ ᏭᏴᎮ ᏣᏄᏏ ᏃᎴ ᏣᏁᎳ ᎠᏂᏎᏂᏏ ᏴᎩ, ᎣᏍᏓ ᏄᏩᏁᎴ ᎠᏦᏴ.
Cheroqui.


8. ¿En qué idioma está el siguiente texto?

ُیعتقد بأن ضابطة في الجیش البریطاني تدعى بریت تشاندي أصبحت أولامرأة من أصول آسیویة ُتكملُ رحلة استكشافیة فردیة عبر .القارة القطبیة الجنوبی  
Árabe.


9. ¿En qué idioma está el siguiente texto?

ગુજરાતી સંસ્કૃત ભાષામાંથી વિકસિત થયેલી આધુનિક ઈન્ડો-આર્યન ભાષા છે. પરંપરાગત રીતે ૩ ઐતિહાસિક તબક્કાઓ પ્રમાણે ઈન્ડો-આર્યન ભાષાઓ વચ્ચે ભેદ કરાય છે.
Guyaratí.


10. ¿En qué idioma está el siguiente texto?

Al Seicento appartiene il primo trattato dedicato non ai volgari italiani o a uno o più di tali volgari, ma alla lingua italiana in quanto tale: Delle osservazioni della lingua italiana di Marcantonio Mambelli, detto il Cinonio.
Italiano.


11. El siguiente texto fue escrito por Robert Burns en escocés. ¿Qué dice Lequel? ¿Qué falla? Justifica por qué ocurre lo que ocurre.

And there's a hand, my trusty fiere! and gie's a hand o' thine! And we’ll tak' a right gude-willie waught, for auld lang syne.

El lequel detecta que se trata de ingles. Esto se debe a que al tratarse de un poema, varias palabras estan escritas mal, para asi
conseguir rimar. Además de esto, al ser tan corto el texto, el programa no puedo obviar dichas ¨trampas¨ y por ello se debe su
falla.


12. El siguiente texto está en inglés. ¿Qué dice Lequel? ¿Qué falla? Justifica por qué ocurre lo que ocurre.

IT WAS THE BEST OF TIMES, IT WAS THE WORST OF TIMES,
IT WAS THE AGE OF WISDOM, IT WAS THE AGE OF FOOLISHNESS,
IT WAS THE EPOCH OF BELIEF, IT WAS THE EPOCH OF INCREDULITY,
IT WAS THE SEASON OF LIGHT, IT WAS THE SEASON OF DARKNESS,
IT WAS THE SPRING OF HOPE, IT WAS THE WINTER OF DESPAIR,
WE HAD EVERYTHING BEFORE US, WE HAD NOTHING BEFORE US,
WE WERE ALL GOING DIRECT TO HEAVEN, WE WERE ALL GOING DIRECT THE OTHER WAY
– IN SHORT, THE PERIOD WAS SO FAR LIKE THE PRESENT PERIOD, THAT SOME OF ITS NOISIEST AUTHORITIES INSISTED ON ITS BEING RECEIVED, FOR GOOD OR FOR EVIL, IN THE SUPERLATIVE DEGREE OF COMPARISON ONLY.

Lequel detecta afrikaans. Esta falla se debe a que el poema al estar escrito en mayúscula, puede detectar dichos trigramas como
inicio de oraciones o de sustantivos propios. Esto se corraboro al programar una funcion, llamada Tolower, la cual convertía las
mayúsculas en minúscula. Tras realizar esto, se confirmo que la problematica reside en la susceptibilidad del programa respecto a las
mayúsculas.

Sin embargo, no se dejo dicha función, ya que luego afectaba a los textos escritos de manera correcta.


## Bonus points

1)La similitud del coseno es una medida de similitud utilizada para determinar qué tan parecidos son dos vectores en función del ángulo
entre ellos. Es un recurso ampliamente utilizado en la minería de textos, que consiste en la extracción de patrones y datos de los 
textos, como en la detección de idiomas. En este trabajo en particular, se utilizó para comparar las frecuencias de los trigramas del 
texto introducido con los perfiles lingüísticos de cada idioma.

Primero, se preprocesa el texto, es decir, se crean los perfiles de trigramas y se cuantifica su frecuencia, la cual se guarda en un 
vector de una dimensión (sería la variable flotante). Luego, se normaliza dicha frecuencia para evitar sesgos debido a la longitud del
texto. Por último, después de tener los vectores a comparar ya normalizados, se utiliza la similitud del coseno para detectar de qué
idioma se trata.

2)El cuello de botella experimentado en textos largos se deben por la limitacion de la memoria asi como del procesamiento de este.
Al ser tan grande dicho archivo de texto, ocupara demasiado espacio y por ende al ser cargado dentro del programa, este consumira una
cantidad muy grande de memoria RAM. Esto puede provocar una falla en la asignación de memoria, el cual deriva en un error de ejecución.

Respecto a la ejecución, hay funciones que tienen una complejidad algoritmica de O(n) o O(nlog(n)), esto provoca que el tiempo de
ejecucion crezca jutno a la cantidad de palabras por archivo de texto. Esto implica, que a mayor cantidad de palabras, mayor sera el
tiempo de ejecución.


# EDAversi

## Integrantes del grupo y contribución al trabajo de cada integrante

* [Nombre]: [contribución]

[completar]

## Parte 1: Generación de movimientos válidos y algoritmo de jugada

[Enumera aquí las pruebas que hiciste para validar que tu generador de movimientos válidos y algoritmo de jugada funcionan correctamente.]

## Parte 2: Implementación del motor de IA

[Enumera aquí las consideraciones que tomaste a la hora de implementar el algoritmo minimax.]

## Parte 3: Poda del árbol

[Justifica por qué el algoritmo minimax de la parte anterior no se completa. Consejo: determina la complejidad computacional.]

## Documentación adicional

[Aquí.]

## Bonus points

[Aquí.]

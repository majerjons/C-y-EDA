# EDAversi

## Integrantes del grupo y contribución al trabajo de cada integrante

* [Lucas Solar Grillo]: [ia.cpp]
* [Andrea Enricci]: [ia.cpp]
* [Matías Asmus]: [model.cpp]
[completar]

## Parte 1: Generación de movimientos válidos y algoritmo de jugada

[Enumera aquí las pruebas que hiciste para validar que tu generador de movimientos válidos y algoritmo de jugada funcionan correctamente.]

## Parte 2: Implementación del motor de IA
Las consideraciones tomadas fueron: 
En primer lugar, programarlo de manera recursiva, asi la propia función generaba su propio arbol recubridor a medida que evalua. Además, se busco
pasar la mayor cantidad de parametros por referencia. Luego, se tomo en cuenta en hacer una funcion de evaluación del tablero, para
ir asignando un puntaje al estado del  juego, siendo esta lo más optima posible en calculo computacional.

## Parte 3: Poda del árbol
Esto se debe a su complejidad computacional exponencial, en la cual el exponente es la profundidad de la busqueda del arbol y la base es el factor de
ramificación del juego(numero promedio de jugadas posibles). Sin poner una altura maxima de poda, el algoritmo iba a tener un tiempo de ejecución
enorme!

## Documentación adicional

[Aquí.]

## Bonus points

[Aquí.]

/**
 * @brief Implements the Reversi game model
 * @author Marc S. Ressl
 *
 * @copyright Copyright (c) 2023-2024
 */

#include "raylib.h"

#include "model.h"


void initModel(GameModel &model)
{
    model.gameOver = true;

    model.playerTime[0] = 0;
    model.playerTime[1] = 0;

    memset(model.board, PIECE_EMPTY, sizeof(model.board));
}

void startModel(GameModel &model)
{
    model.gameOver = false;

    model.currentPlayer = PLAYER_BLACK;

    model.playerTime[0] = 0;
    model.playerTime[1] = 0;
    model.turnTimer = GetTime();

    memset(model.board, PIECE_EMPTY, sizeof(model.board));
    model.board[BOARD_SIZE / 2 - 1][BOARD_SIZE / 2 - 1] = PIECE_WHITE;
    model.board[BOARD_SIZE / 2 - 1][BOARD_SIZE / 2] = PIECE_BLACK;
    model.board[BOARD_SIZE / 2][BOARD_SIZE / 2] = PIECE_WHITE;
    model.board[BOARD_SIZE / 2][BOARD_SIZE / 2 - 1] = PIECE_BLACK;
}

Player getCurrentPlayer(GameModel &model)
{
    return model.currentPlayer;
}

int getScore(GameModel &model, Player player)
{
    int score = 0;

    for (int y = 0; y < BOARD_SIZE; y++)
        for (int x = 0; x < BOARD_SIZE; x++)
        {
            if (((model.board[y][x] == PIECE_WHITE) &&
                 (player == PLAYER_WHITE)) ||
                ((model.board[y][x] == PIECE_BLACK) &&
                 (player == PLAYER_BLACK)))
                score++;
        }

    return score;
}

double getTimer(GameModel &model, Player player)
{
    double turnTime = 0;

    if (!model.gameOver && (player == model.currentPlayer))
        turnTime = GetTime() - model.turnTimer;

    return model.playerTime[player] + turnTime;
}

Piece getBoardPiece(GameModel &model, Square square)
{
    return model.board[square.y][square.x];
}

void setBoardPiece(GameModel &model, Square square, Piece piece)
{
    model.board[square.y][square.x] = piece;
}

bool isSquareValid(Square square)
{
    return (square.x >= 0) &&
           (square.x < BOARD_SIZE) &&
           (square.y >= 0) &&
           (square.y < BOARD_SIZE);
}

void getValidMoves(GameModel& model, Moves& validMoves)
{
    Piece CurrentPiece =
        (getCurrentPlayer(model) == PLAYER_WHITE)
        ? PIECE_WHITE
        : PIECE_BLACK;

    Piece RivalPiece =
        (getCurrentPlayer(model) == PLAYER_WHITE)
        ? PIECE_BLACK
        : PIECE_WHITE;

    for (int y = 0; y < BOARD_SIZE; y++)
    {
        for (int x = 0; x < BOARD_SIZE; x++)
        {
            Square move = { x, y };

                                                                 // Busco casillas vacias con piezas rivales adyacentes en 
                                                                 // direcciones
            if (getBoardPiece(model, move) == PIECE_EMPTY)
            {   
                                                                 
                bool validMove = false;

                                                                  
                for (int dirX = -1; dirX <= 1; dirX++)
                {
                    for (int dirY = -1; dirY <= 1; dirY++)
                    {
                        if (dirX == 0 && dirY == 0)
                            continue;

                        Square adjacent = { move.x + dirX, move.y + dirY };
                        if (!isSquareValid(adjacent))
                            continue;

                        Piece adjacentPiece = getBoardPiece(model, adjacent);
                        if (adjacentPiece == RivalPiece)
                        {
                                                                                    // Veo si completa una linea (capturo fichas rivales)
                            Square lineEnd = adjacent;
                            bool lineValid = false;

                            while (isSquareValid(lineEnd))
                            {
                                Piece piece = getBoardPiece(model, lineEnd);
                                if (piece == CurrentPiece)                          
                                {
                                    lineValid = true;
                                    break;
                                }
                                else if (piece == PIECE_EMPTY)
                                {
                                    break;
                                }
                                lineEnd.x += dirX;
                                lineEnd.y += dirY;
                            }

                            if (lineValid)
                            {
                                validMove = true;
                                break;
                            }
                        }
                    }
                    if (validMove)
                        break;
                }

                                                                // Si es un movimiento valido lo agrego a la lista
                if (validMove)
                    validMoves.push_back(move);
            }
        }
    }
}











bool playMove(GameModel& model, Square move)
{
    Piece piece =
        (getCurrentPlayer(model) == PLAYER_WHITE)
        ? PIECE_WHITE
        : PIECE_BLACK;

    setBoardPiece(model, move, piece);

    
    Piece CurrentPiece = piece;
    Piece RivalPiece =
        (getCurrentPlayer(model) == PLAYER_WHITE)
        ? PIECE_BLACK
        : PIECE_WHITE;

    
    for (int dirX = -1; dirX <= 1; dirX++)
    {
        for (int dirY = -1; dirY <= 1; dirY++)
        {
            if (dirX == 0 && dirY == 0)
                continue;

            Square adjacent = { move.x + dirX, move.y + dirY };
            if (!isSquareValid(adjacent))
                continue;

            Piece adjacentPiece = getBoardPiece(model, adjacent);
            if (adjacentPiece == RivalPiece)
            {
                
                Square lineEnd = adjacent;
                bool lineValid = false;

                while (isSquareValid(lineEnd))
                {
                    Piece piece = getBoardPiece(model, lineEnd);
                    if (piece == CurrentPiece)
                    {
                        lineValid = true;
                        break;
                    }
                    else if (piece == PIECE_EMPTY)
                    {
                        break;
                    }
                    lineEnd.x += dirX;
                    lineEnd.y += dirY;
                }

                if (lineValid)
                {
                                                                                    // cambio de color las fichas capturadas
                    Square flipSquare = adjacent;
                    while (flipSquare.x != lineEnd.x || flipSquare.y != lineEnd.y)
                    {
                        setBoardPiece(model, flipSquare, CurrentPiece);
                        flipSquare.x += dirX;
                        flipSquare.y += dirY;
                    }
                }
            }
        }
    }

    // Update timer
    double currentTime = GetTime();
    model.playerTime[model.currentPlayer] += currentTime - model.turnTimer;
    model.turnTimer = currentTime;

    // Swap player
    model.currentPlayer =
        (model.currentPlayer == PLAYER_WHITE)
        ? PLAYER_BLACK
        : PLAYER_WHITE;

    // Game over?
    Moves validMoves;
    getValidMoves(model, validMoves);

    if (validMoves.empty())
        model.gameOver = true;

    return true;
}
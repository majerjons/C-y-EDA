/**
 * @brief Implements the Reversi game AI
 * @author Marc S. Ressl
 *
 * @copyright Copyright (c) 2023-2024
 */

#include <cstdlib>

#include "ai.h"
#include "controller.h"

Square getBestMove(GameModel &model)
{
    int bestValue = -1000;
    int depth = DEPTH;
    Square bestMove;
    Moves validMoves;
    getValidMoves(model, validMoves);
    for (auto move : validMoves)
    {
        GameModel modelCopy = model;    //Copio el estado del juego como variable auxiliar y evito que el usuario vea lo que hace la IA
        playMove(modelCopy, move);  
        int value = miniMax(modelCopy, depth, false, model.currentPlayer); //llamo con false pues, estoy buscando maximizar mi valor.
        if (value > bestValue) 
        {
            bestValue = value;
            bestMove = move;
        }
    }
    return bestMove;
}


static int miniMax(GameModel& modelCopy, int depth, bool maximizingPlayer, Player player)
{
    if (depth == 0 || modelCopy.gameOver) 
    {
        return evaluateBoard(modelCopy, player);
    }
    if (maximizingPlayer) // Si es el turno del jugador que est� maximizando
    {
        int maxValue = -1000;
        Moves validMoves;
        getValidMoves(modelCopy, validMoves);
        for (auto move : validMoves)
        {
            GameModel newModel = modelCopy;
            playMove(newModel, move); 
            int lastValue = miniMax(newModel, depth - 1, false, player); //Llamo a miniMax de manera recursiva pero un nivel m�s abajo.
            maxValue = std::max(maxValue, lastValue); 
            return maxValue;
        }
    }
    else 
    {   
        int minValue = 1000;
        Moves validMoves;
        getValidMoves(modelCopy, validMoves);
        for (auto move : validMoves) 
        {
            GameModel newModel = modelCopy;
            playMove(newModel, move);
            int lastValue = miniMax(newModel, depth - 1, true, player);
            minValue = std::min(minValue, lastValue);
        }
        return minValue;
    }
}



static int evaluateBoard(GameModel& model, Player player)   //El criterio es restar si tiene piezas adyacentes del mismo equipo y sumar si son enemigas.
{
    int score = 0;
    Piece piece = 
        (player == PLAYER_WHITE) 
        ? PIECE_WHITE 
        : PIECE_BLACK;
    for (int y = 0; y < BOARD_SIZE; y++)
    {
        for (int x = 0; x < BOARD_SIZE; x++)    //recorro todo el tablero
        {
            if (model.board[x][y] == piece)
            {
                int auxScore = 0;
                for (int i = -1; i <= 1; i++)   //recorro las posiciones adyacentes a la posicion relativa del tiro
                {
                    for (int j = -1; j <= 1; j++)
                    {
                        if (i == 0 && j == 0)   //La posici�n (0,0) es donde se encuentra mi pieza.
                        {
                            continue;
                        }
                        if (isSquareValid({ x + i, y + j }))
                        {
                            auxScore -=
                                (model.board[x + i][y + j] == piece)
                                ? 1
                                : 0;
                        }
                        else
                        {
                            score += 2;
                        }
                    }
                }
                score += auxScore;
                score += 4; //Ajusto el score, el valor optimo es 4
            }
        }
    }

    return score;
}